#!/bin/bash
python3 multi_data_processing.py
python3 map_reduce.py
python3 web_db_data.py